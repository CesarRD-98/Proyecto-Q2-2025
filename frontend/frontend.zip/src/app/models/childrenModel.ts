import { ReactNode } from "react";

export interface ChildrenModel {
    children: ReactNode
}